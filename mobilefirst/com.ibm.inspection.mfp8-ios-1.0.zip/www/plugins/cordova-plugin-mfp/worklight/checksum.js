var WL_CHECKSUM = {"checksum":2578462653,"date":1475856652220,"machine":"Curtiss-MacBook-Pro-2.local"}
/* Date: Fri Oct 07 2016 12:10:52 GMT-0400 (EDT) */