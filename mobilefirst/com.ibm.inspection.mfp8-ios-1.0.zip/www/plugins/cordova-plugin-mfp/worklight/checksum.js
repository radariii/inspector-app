var WL_CHECKSUM = {"checksum":753706810,"date":1470088320328,"machine":"Curtiss-MacBook-Pro-2.local"}
/* Date: Mon Aug 01 2016 17:52:00 GMT-0400 (EDT) */